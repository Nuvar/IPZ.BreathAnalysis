public class TestWavelet
{
    public static double Wavelet(double t, int T)
    {
        return t*T;
    }
}